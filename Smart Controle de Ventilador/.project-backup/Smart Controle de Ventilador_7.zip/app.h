/*
 * app.h
 *
 * Created: 06/12/2022 11:12:26
 *  Author: lpedroso
 */ 


#ifndef APP_H_
#define APP_H_
typedef enum {
	up,
	down
} dir;

void set_lamp_output(bool state);
void toggle_lamp_output();
void set_fan_output(output_state state);
void toggle_fan_output();
void set_fan_direction(dir direction);
void toggle_direction_relay();
void increase_speed();
void decrease_speed();

#endif /* APP_H_ */