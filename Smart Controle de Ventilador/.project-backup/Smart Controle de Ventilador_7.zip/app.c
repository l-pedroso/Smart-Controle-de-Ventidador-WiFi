/*
 * app.c
 *
 * Created: 06/12/2022 11:12:07
 *  Author: lpedroso
 */ 

#include "triac_driver.h"
#include "app.h"
#include "atmel_start_pins.h"

static uint8_t fan_speed = 0;
static dir fan_direction = down; 
static output_state fan_state = off;
static uint8_t angle = triac_get_angle();



void set_lamp_output(bool state){
	Rele3_set_level(state);
}

void toggle_lamp_output(){	
	//ToDo zerocross implementation
	Rele3_toggle_level();
}


void set_fan_output(output_state state){
	triac_set_output_state(state);
}

void toggle_fan_output(){
	if(fan_state == on){
		fan_state = off;
		triac_set_output_state(fan_state);
	}else{
		fan_state = on;
		triac_set_output_state(fan_state);
	}
}

void set_fan_direction(dir direction){
	
	if(triac_get_output_state() == on){
	    fan_direction = direction;
		cnt_direction = 30000;
		rele1 = 0;
		rele2 = 0;
	}
}

void toggle_direction_relay(){
	
	if(triac_get_output_state() == on){
		if(fan_direction == down){
			 rele1 = 1;
			 rele2 = 0;
		}
	    if(fan_direction == up){
			 rele1 = 0;
			 rele2 = 1;
		}
	}
}

void increase_speed(){
	if(triac_get_output_state() == on){
		if(angle > 0) angle -= 20;
		triac_set_angle(angle);
	}
}

void decrease_speed(){	
	if(triac_get_output_state() == on){
		if(angle < 160) angle += 20;
		triac_set_angle(angle);
	}	
}