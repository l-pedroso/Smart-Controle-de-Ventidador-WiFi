/*
 * triac_driver.c
 *
 * Created: 06/12/2022 10:34:42
 *  Author: lpedroso
 */ 


bool driver_started = 0;
static triac_driver_config driver_config;


void triac_driver_init(triac_driver_config user_config){
	driver_config = user_config;
	driver_started = 1;
}

void triac_driver_tick(){
	if(driver_started){
		tick_process();
	}
}

void triac_set_angle(uint8_t angle){
	if(angle > MAX_ANGLE) angle = MAX_ANGLE;
	if(angle < MIN_ANGLE) angle = MIN_ANGLE;
	driver_config.trigger_angle = angle;
}


uint8_t triac_get_angle(){
	return driver_config.trigger_angle;
}


void triac_set_output_state(output_state state) {
	driver_config.triac_state = state;		
}

output_state triac_get_output_state(){
	return driver_config.triac_state;
}

static void tick_process(){
	//ToDo
}
